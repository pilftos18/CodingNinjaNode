// Please don't change the pre-written code
// Import the necessary modules here

export default class ProductModel {
  fetchProducts = () => {
    // Write your code here
  };
}
