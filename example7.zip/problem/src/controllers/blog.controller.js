// Please don't change the pre-written code
// Import the necessary modules here

export const renderBlogs = () => {
  // Write your code here
};
export const renderBlogForm = () => {
  // Write your code here
};
export const addBlog = () => {
  // Write your code here
};
