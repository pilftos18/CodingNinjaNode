// Please don't change the pre-written code
// Import the necessary modules here

export const userController = async (req, res) => {
  // Write your code here
};
